require 'test_helper'

class QuotesHelperTest < ActionView::TestCase
end
