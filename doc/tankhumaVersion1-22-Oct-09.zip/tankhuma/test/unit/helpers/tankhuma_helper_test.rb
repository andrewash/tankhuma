require 'test_helper'

class TankhumaHelperTest < ActionView::TestCase
end
