class Quote < ActiveRecord::Base
  has_many :words    
end
